export const COLORS = {
    lightBlue: '#93E3FE',
    lightGreen: '#B0DC8B',
    lightYellow: '#FDF894',
    coral: '#D97575'
}