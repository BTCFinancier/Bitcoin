const assignedToAVar = useVariable(
    'simple-case',
    false,
)?.value

useVariableValue(
    'simple-case',
    false,
)?.value

useDVCVariable(
    'simple-case',
    false,
)?.value