// eslint-disable-next-line no-unused-vars
import hardhat from "hardhat";

async function main() {
  console.log(`Deploying CrossChainCounter...`);
}

main().catch((error) => {
  console.error(error);
  process.exit(1);
});
