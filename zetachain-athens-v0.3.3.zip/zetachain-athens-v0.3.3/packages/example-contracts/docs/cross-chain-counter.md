# Cross Chain Counter

[![Docs](https://img.shields.io/badge/Zeta%20docs-🔗-43ad51)](https://docs.zetachain.com/develop/examples/cross-chain-counter)

A simple cross-chain counter using [Zeta Connector](https://docs.zetachain.com/reference/connector).
