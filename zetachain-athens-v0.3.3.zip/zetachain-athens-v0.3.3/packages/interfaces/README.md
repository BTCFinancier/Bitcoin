# ZetaChain interfaces

This package includes the interfaces to use Zetachain like abi and TS types.
