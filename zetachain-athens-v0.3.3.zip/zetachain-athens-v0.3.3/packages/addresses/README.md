# ZetaChain addresses

This package includes the addresses and networks to use Zetachain.
