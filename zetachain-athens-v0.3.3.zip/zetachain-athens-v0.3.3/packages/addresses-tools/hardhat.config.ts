import { HardhatUserConfig } from "hardhat/types";

const config: HardhatUserConfig = {};

export default config;
